import 'package:divar/api/networkService.dart';
import 'package:divar/login_screen.dart';
import 'package:divar/splash_screen.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:persian_number_utility/persian_number_utility.dart';
import 'package:provider/provider.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (BuildContext context) => NetworkService(),
      child: MaterialApp(
        title: 'divar',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(fontFamily: 'IranSans'),
        home: LoginScreen(),
      ),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance!.addPostFrameCallback((_) {
      Provider.of<NetworkService>(context, listen: false).getAds();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: 2,
        selectedFontSize: 0,
        unselectedFontSize: 0,
        items: [
          BottomNavigationBarItem(
              backgroundColor: Color(0xFF303030),
              icon: Column(
                children: [
                  SvgPicture.asset(
                    'icons/User.svg',
                    width: 20,
                    color: Color(0xFFEBEBEB),
                    fit: BoxFit.contain,
                  ),
                  Text(
                    'دیوار من',
                    style: TextStyle(color: Color(0xFFEBEBEB), fontSize: 12),
                  )
                ],
              ),
              title: SizedBox()),
          BottomNavigationBarItem(
              backgroundColor: Color(0xFF303030),
              icon: Column(
                children: [
                  SvgPicture.asset('icons/Message Align Right.svg',
                      width: 20, fit: BoxFit.contain, color: Color(0xFFEBEBEB)),
                  Text(
                    'چت دیوار',
                    style: TextStyle(color: Color(0xFFEBEBEB), fontSize: 12),
                  )
                ],
              ),
              title: SizedBox()),
          BottomNavigationBarItem(
              backgroundColor: Color(0xFF303030),
              icon: Column(
                children: [
                  SvgPicture.asset('icons/Add.svg',
                      width: 20, fit: BoxFit.contain, color: Color(0xFFEBEBEB)),
                  Text(
                    'ثبت آگهی',
                    style: TextStyle(color: Color(0xFFEBEBEB), fontSize: 12),
                  )
                ],
              ),
              title: SizedBox()),
          BottomNavigationBarItem(
              backgroundColor: Color(0xFF303030),
              icon: Column(
                children: [
                  SvgPicture.asset('icons/Justified.svg',
                      width: 20, fit: BoxFit.contain, color: Color(0xFFEBEBEB)),
                  Text(
                    'دسته ها',
                    style: TextStyle(color: Color(0xFFEBEBEB), fontSize: 12),
                  )
                ],
              ),
              title: SizedBox()),
          BottomNavigationBarItem(
            backgroundColor: Color(0xFF303030),
            icon: Column(
              children: [
                SvgPicture.asset('icons/Personal card 2.svg',
                    width: 20, fit: BoxFit.contain, color: Color(0xFFD14858)),
                Text(
                  'آگهی ها',
                  style: TextStyle(color: Color(0xFFD14858), fontSize: 12),
                )
              ],
            ),
            title: SizedBox(),
          )
        ],
      ),
      backgroundColor: Color(0xFF212121),
      body: SafeArea(
          child: Provider.of<NetworkService>(context).loading == false
              ? Column(
                  children: [
                    Container(
                        color: Color(0xFF303030),
                        height: MediaQuery.of(context).size.height * 0.23,
                        child: Column(
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: TextField(
                                textDirection: TextDirection.rtl,
                                decoration: InputDecoration(
                                    suffixIcon: Icon(Icons.search,
                                        color: Color(0xFFC8C8C8), size: 25),
                                    isDense: true,
                                    contentPadding: EdgeInsets.all(8),
                                    hintText: 'جستجو در همه آگهی ها',
                                    hintStyle: TextStyle(
                                        color: Color(0xFFC8C8C8), fontSize: 17),
                                    hintTextDirection: TextDirection.rtl,
                                    enabledBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(7)),
                                    focusedBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(7)),
                                    border: InputBorder.none,
                                    fillColor: Color(0xFF707070),
                                    filled: true),
                                style: TextStyle(
                                  color: Color(0xFFC8C8C8),
                                  fontSize: 18,
                                ),
                              ),
                            ),
                            SizedBox(height: 10),
                            Expanded(
                              child: ListView(
                                scrollDirection: Axis.horizontal,
                                reverse: true,
                                itemExtent: 95,
                                children: [
                                  CategoriesItem(
                                      title: 'املاک', asset: 'icons/Home.svg'),
                                  CategoriesItem(
                                      title: 'وسایل نقلیه',
                                      asset: 'icons/car.svg'),
                                  CategoriesItem(
                                      title: 'کالای دیجیتال',
                                      asset: 'icons/Camera.svg'),
                                  CategoriesItem(
                                      title: 'خانه و آشپزخانه',
                                      asset: 'icons/Baking.svg'),
                                  CategoriesItem(
                                      title: 'سرگرمی و فراغت',
                                      asset: 'icons/PS5.svg'),
                                ],
                              ),
                            ),
                          ],
                        )),
                    SizedBox(height: 20),
                    Expanded(
                        child: ListView.builder(
                            itemCount: Provider.of<NetworkService>(context)
                                    .ad
                                    ?.length ??
                                0,
                            itemBuilder: (BuildContext context, int index) {
                              return AdvertisementWidget(
                                  title: Provider.of<NetworkService>(context)
                                      .ad![index]
                                      .title
                                      .toString(),
                                  region: 'لحظاتی پیش در ' +
                                      Provider.of<NetworkService>(context)
                                          .ad![index]
                                          .district!
                                          .name
                                          .toString(),
                                  asset: 'assets/13.png',
                                  price: Provider.of<NetworkService>(context)
                                      .ad![index]
                                      .infos!
                                      .last
                                      .infoValue
                                      .toString());
                            }))
                  ],
                )
              : Center(
                  child: CircularProgressIndicator(
                  color: Color(0xFFD14858),
                ))),
    );
  }
}

class CategoriesItem extends StatelessWidget {
  CategoriesItem({required this.title, required this.asset});
  String title, asset;
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          height: 45,
          width: 45,
          decoration: BoxDecoration(
              color: Color(0xFF424242),
              borderRadius: BorderRadius.circular(50),
              border: Border.all(color: Color(0xFF757575))),
          child: Center(
              child: SvgPicture.asset(asset,
                  color: Color(0xFFBEBEBE), height: 25, width: 25)),
        ),
        SizedBox(height: 5),
        Text(
          title,
          style: TextStyle(color: Color(0xFFBEBEBE), fontSize: 12.5),
          softWrap: true,
        )
      ],
    );
  }
}

class AdvertisementWidget extends StatelessWidget {
  AdvertisementWidget(
      {required this.title,
      required this.region,
      required this.asset,
      required this.price});
  String title, region, asset, price;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(5),
                child: Image.asset(
                  asset,
                  width: 150,
                  height: 150,
                  fit: BoxFit.cover,
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(title,
                      style: TextStyle(fontSize: 17, color: Colors.white),
                      textDirection: TextDirection.rtl,
                      textAlign: TextAlign.right),
                  SizedBox(height: 50),
                  Text(price.toPersianDigit() + ' تومان ',
                      style: TextStyle(fontSize: 13, color: Color(0xFFB4B4B4)),
                      textDirection: TextDirection.rtl,
                      textAlign: TextAlign.right),
                  SizedBox(height: 3),
                  Text(region,
                      style: TextStyle(fontSize: 13, color: Color(0xFFB4B4B4)),
                      textDirection: TextDirection.rtl,
                      textAlign: TextAlign.right),
                ],
              ),
            ],
          ),
          SizedBox(height: 10),
          Divider(color: Color(0xFF707070))
        ],
      ),
    );
  }
}
