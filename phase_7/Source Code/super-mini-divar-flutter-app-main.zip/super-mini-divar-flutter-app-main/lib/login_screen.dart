import 'package:flutter/material.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  String? phoneNumber;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF212121),
      body: SafeArea(
          child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Container(
            height: 60,
            width: double.infinity,
            color: const Color(0xFF303030),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Text('ورود به حساب کاربری',
                    style: TextStyle(fontSize: 16, color: Colors.white)),
                IconButton(
                    onPressed: () {},
                    icon: Icon(
                      Icons.arrow_forward_ios_sharp,
                      size: 18,
                      color: Colors.white,
                    ))
              ],
            ),
          ),
          const SizedBox(height: 15),
          const Padding(
            padding: EdgeInsets.all(8.0),
            child: Text(
              'شماره موبایل خود را وارد کنید',
              style: TextStyle(color: Colors.white, fontSize: 17),
              textDirection: TextDirection.rtl,
            ),
          ),
          const SizedBox(height: 10),
          const Padding(
            padding: EdgeInsets.all(8.0),
            child: Text(
              'برای استفاده از امکانات دیوار لطفا شماره موبایل خود را وارد کنید. کد تایید به شماره پیامک خواهد شد.',
              style: TextStyle(color: Color(0xFFB4B4B4), fontSize: 15),
              textDirection: TextDirection.rtl,
            ),
          ),
          const SizedBox(height: 10),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextFormField(
              keyboardType: TextInputType.number,
              textInputAction: TextInputAction.done,
              style: const TextStyle(color: Colors.white, fontSize: 16),
              cursorColor: const Color(0xFFD14858),
              decoration: InputDecoration(
                  enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(7),
                      borderSide: const BorderSide(color: Color(0xFFD14858))),
                  focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(7),
                      borderSide: const BorderSide(color: Color(0xFFD14858)))),
              onChanged: (value) {
                setState(() {
                  phoneNumber = value;
                });
              },
            ),
          ),
          const Spacer(),
          Container(
            height: 70,
            width: double.infinity,
            color: const Color(0xFF303030),
            child: Stack(
              children: [
                Positioned(
                  left: 10,
                  top: 12,
                  child: MaterialButton(
                    padding: EdgeInsets.symmetric(vertical: 10, horizontal: 60),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(7)),
                    onPressed: () {},
                    color: Color(0xFFD14858),
                    height: 35,
                    child: const Text('ورود',
                        style: TextStyle(fontSize: 16, color: Colors.white)),
                  ),
                ),
              ],
            ),
          )
        ],
      )),
    );
  }
}
