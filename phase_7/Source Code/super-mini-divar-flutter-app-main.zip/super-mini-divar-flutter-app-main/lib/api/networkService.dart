// ignore_for_file: file_names

import 'dart:convert';

import 'package:divar/api/ad.dart';
import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;

class NetworkService extends ChangeNotifier {
  List<Ad>? ad;
  bool loading = true;
  int? resCode;
  Future<void> getAds() async {
    var url = Uri.parse("http://divar.rubberduck.ir:5000/ad/");
    try {
      loading = true;
      notifyListeners();
      var response = await http.get(url);
      if (response.statusCode == 200) {
        resCode = 200;
        ad = adFromJson(utf8.decode(response.bodyBytes));
        loading = false;
        notifyListeners();
      } else {
        loading = false;
        resCode = 404;
        notifyListeners();
      }
    } catch (e) {
      resCode = 404;
      loading = false;
      notifyListeners();
      print("Somthing Went Wrong");
    }
  }

  @override
  void notifyListeners() {
    super.notifyListeners();
  }
}
