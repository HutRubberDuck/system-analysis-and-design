import 'dart:convert';

List<Ad> adFromJson(String str) => List<Ad>.from(json.decode(str).map((x) => Ad.fromJson(x)));

String adToJson(List<Ad> data) => json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class Ad {
    Ad({
        this.title,
        this.createdAt,
        this.userId,
        this.districtId,
        this.id,
        this.description,
        this.expiredAt,
        this.acceptedByAdminId,
        this.categoryId,
        this.infos,
        this.district,
        this.category,
    });

    String? title;
    DateTime? createdAt;
    int? userId;
    int? districtId;
    int? id;
    String? description;
    DateTime? expiredAt;
    dynamic acceptedByAdminId;
    int? categoryId;
    List<Info>? infos;
    District? district;
    Category? category;

    factory Ad.fromJson(Map<String, dynamic> json) => Ad(
        title: json["title"],
        createdAt: DateTime.parse(json["created_at"]),
        userId: json["user_id"],
        districtId: json["district_id"],
        id: json["id"],
        description: json["description"],
        expiredAt: DateTime.parse(json["expired_at"]),
        acceptedByAdminId: json["accepted_by_admin_id"],
        categoryId: json["category_id"],
        infos: List<Info>.from(json["infos"].map((x) => Info.fromJson(x))),
        district: District.fromJson(json["district"]),
        category: Category.fromJson(json["category"]),
    );

    Map<String, dynamic> toJson() => {
        "title": title,
        "created_at": createdAt!.toIso8601String(),
        "user_id": userId,
        "district_id": districtId,
        "id": id,
        "description": description,
        "expired_at": expiredAt!.toIso8601String(),
        "accepted_by_admin_id": acceptedByAdminId,
        "category_id": categoryId,
        "infos": List<dynamic>.from(infos!.map((x) => x.toJson())),
        "district": district!.toJson(),
        "category": category!.toJson(),
    };
}

class Category {
    Category({
        this.name,
        this.id,
    });

    String? name;
    int? id;

    factory Category.fromJson(Map<String, dynamic> json) => Category(
        name: json["name"],
        id: json["id"],
    );

    Map<String, dynamic> toJson() => {
        "name": name,
        "id": id,
    };
}

class District {
    District({
        this.id,
        this.cityId,
        this.name,
        this.city,
    });

    int? id;
    int? cityId;
    String? name;
    City? city;

    factory District.fromJson(Map<String, dynamic> json) => District(
        id: json["id"],
        cityId: json["city_id"],
        name: json["name"],
        city: City.fromJson(json["city"]),
    );

    Map<String, dynamic> toJson() => {
        "id": id,
        "city_id": cityId,
        "name": name,
        "city": city!.toJson(),
    };
}

class City {
    City({
        this.id,
        this.name,
        this.provinceId,
    });

    int? id;
    String? name;
    int? provinceId;

    factory City.fromJson(Map<String, dynamic> json) => City(
        id: json["id"],
        name: json["name"],
        provinceId: json["province_id"],
    );

    Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "province_id": provinceId,
    };
}

class Info {
    Info({
        this.advertisingId,
        this.infoValue,
        this.infoDetailId,
        this.infoDetail,
    });

    int? advertisingId;
    String? infoValue;
    int? infoDetailId;
    InfoDetail? infoDetail;

    factory Info.fromJson(Map<String, dynamic> json) => Info(
        advertisingId: json["advertising_id"],
        infoValue: json["info_value"],
        infoDetailId: json["info_detail_id"],
        infoDetail: InfoDetail.fromJson(json["info_detail"]),
    );

    Map<String, dynamic> toJson() => {
        "advertising_id": advertisingId,
        "info_value": infoValue,
        "info_detail_id": infoDetailId,
        "info_detail": infoDetail!.toJson(),
    };
}

class InfoDetail {
    InfoDetail({
        this.id,
        this.title,
    });

    int? id;
    String? title;

    factory InfoDetail.fromJson(Map<String, dynamic> json) => InfoDetail(
        id: json["id"],
        title: json["title"],
    );

    Map<String, dynamic> toJson() => {
        "id": id,
        "title": title,
    };
}
